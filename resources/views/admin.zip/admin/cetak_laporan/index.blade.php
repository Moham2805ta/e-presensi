@extends('admin.layout.master')

@section('content')
<div class="card mt-4 mb-3">
    <div class="card-body">
        <h4>Cetak Laporan</h4>
        <p>
            Ini tempat Cetak laporan
        </p>
    </div>
</div>
@endsection