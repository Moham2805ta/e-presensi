<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Karyawan;
use Illuminate\Support\Facades\Hash;


class karyawanController extends Controller
{
    public function index()
    {
        $karyawan = karyawan::all();
        return view('admin.karyawan.index', compact('karyawan'));
    }

    public function create() {
        return view('admin.karyawan.tambah');
    }

    public function store(Request $request) {
        $validateData = $request->validate([
            'nama' => 'required|regex:/^[a-zA-Z\s]+$/|min:3',
            'nik' => 'required|unique:karyawans|size:16',
            'alamat' => 'required|min:3',
            'password' => 'required|min:5',
        ]);

        $karyawan = new Karyawan();
        $karyawan->nik = $validateData['nik'];
        $karyawan->nama_lengkap = $validateData['nama'];
        $karyawan->no_hp = '0812';
        $karyawan->jabatan = 'karyawan';
        $karyawan->password =  Hash::make($validateData['password']);
        $karyawan->save();

        return redirect()->route('karyawan.index')
                ->with('tambah',"penambahan data {$validateData['nama']} berhasil");

    }

    public function edit(karyawan $karyawan){
        return view('admin.karyawan.edit',['karyawan' => $karyawan]);
    }

    public function destroy(karyawan $karyawan){
        $karyawan->delete();
        return redirect()->route('karyawan.index')->with('hapus',"hapus data $karyawan->nama_lengkap berhasil");

    }

    public function update(karyawan $karyawan, Request $request){
        $karyawan = karyawan::find($karyawan->id); // Pastikan $karyawan_id adalah id yang benar
        $validateData = $request->validate([
            'nama' => 'required|regex:/^[a-zA-Z\s]+$/|min:3',
            'nik' => 'required|size:16|unique:karyawans,nik,'.$karyawan->id,
            'alamat' => 'required|min:3',
            'password' => 'nullable|min:5',
        ]);

        $karyawan = new Karyawan();
        $karyawan->nik = $validateData['nik'];
        $karyawan->nama_lengkap = $validateData['nama'];
        $karyawan->no_hp = '0812';
        $karyawan->jabatan = 'karyawan';

        if(trim($validateData['password']) !== '') {
            $karyawan->password = Hash::make($validateData['password']);
        }

        $karyawan->save();
        return redirect()->route('karyawan.index')->with('ubah',"Update data {$validateData['nama']} berhasil");
    }

}
